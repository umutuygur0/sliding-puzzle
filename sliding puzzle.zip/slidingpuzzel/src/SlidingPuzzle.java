import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class SlidingPuzzle extends JFrame {
    private JPanel mainPanel;
    private JPanel puzzlePanel;
    private JPanel controlPanel;
    private JButton[] buttons;
    private int size;
    private boolean useKeyboard;
    private BufferedImage originalImage;
    private List<BufferedImage> images;
    private int emptyIndex;
    private static final int SHUFFLE_MOVES = 1000;
    private KeyAdapter keyAdapter;

    public SlidingPuzzle() {
        setTitle("Sliding Puzzle");
        setSize(600, 600); // Increased height to accommodate control panel
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        showMainMenu();
    }

    private void showMainMenu() {
        if (mainPanel != null) {
            remove(mainPanel);
        }
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(4, 1));

        JLabel welcomeLabel = new JLabel("Welcome to Sliding Puzzle", SwingConstants.CENTER);
        mainPanel.add(welcomeLabel);

        JButton threeByThreeButton = new JButton("3x3 Numbers");
        threeByThreeButton.addActionListener(e -> showControlMenu(3));
        mainPanel.add(threeByThreeButton);

        JButton fourByFourButton = new JButton("4x4 Numbers");
        fourByFourButton.addActionListener(e -> showControlMenu(4));
        mainPanel.add(fourByFourButton);

        JButton pictureButton = new JButton("3x3 Picture");
        pictureButton.addActionListener(e -> showControlMenu(3, true));
        mainPanel.add(pictureButton);

        add(mainPanel);
        revalidate();
        repaint();
    }

    private void showControlMenu(int puzzleSize) {
        showControlMenu(puzzleSize, false);
    }

    private void showControlMenu(int puzzleSize, boolean isPicturePuzzle) {
        remove(mainPanel);
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1));

        JLabel controlLabel = new JLabel("Select Control Method", SwingConstants.CENTER);
        mainPanel.add(controlLabel);

        JButton mouseControlButton = new JButton("Mouse Control");
        mouseControlButton.addActionListener(e -> startPuzzle(puzzleSize, false, isPicturePuzzle));
        mainPanel.add(mouseControlButton);

        JButton keyboardControlButton = new JButton("Keyboard Control");
        keyboardControlButton.addActionListener(e -> startPuzzle(puzzleSize, true, isPicturePuzzle));
        mainPanel.add(keyboardControlButton);

        add(mainPanel);
        revalidate();
        repaint();
    }

    private void startPuzzle(int puzzleSize, boolean useKeyboard, boolean isPicturePuzzle) {
        this.size = puzzleSize;
        this.useKeyboard = useKeyboard;

        if (isPicturePuzzle) {
            try {
                originalImage = ImageIO.read(new File("C:\\Users\\Lenovo\\OneDrive\\Masaüstü\\buuu.jpg"));
                images = splitImage(originalImage, size, size);
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }

        remove(mainPanel);
        if (puzzlePanel != null) {
            remove(puzzlePanel);
        }
        if (controlPanel != null) {
            remove(controlPanel);
        }
        puzzlePanel = new JPanel();
        puzzlePanel.setLayout(new GridLayout(size, size));
        buttons = new JButton[size * size];

        // Initialize the puzzle in correct order
        for (int i = 0; i < size * size - 1; i++) {
            if (isPicturePuzzle) {
                buttons[i] = new JButton(new ImageIcon(images.get(i)));
            } else {
                buttons[i] = new JButton(String.valueOf(i + 1));
            }
            if (!useKeyboard) {
                buttons[i].addActionListener(new ButtonListener());
            }
            puzzlePanel.add(buttons[i]);
        }
        buttons[size * size - 1] = new JButton(""); // Empty space
        if (!useKeyboard) {
            buttons[size * size - 1].addActionListener(new ButtonListener());
        }
        puzzlePanel.add(buttons[size * size - 1]);
        emptyIndex = size * size - 1; // Set the initial empty index

        controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(1, 2));
        JButton shuffleButton = new JButton("Shuffle");
        shuffleButton.addActionListener(e -> {
            shufflePuzzle(SHUFFLE_MOVES);
            setFocusable(true);
            requestFocusInWindow();
        });
        controlPanel.add(shuffleButton);

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(e -> exitToMainMenu());
        controlPanel.add(exitButton);

        add(puzzlePanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        if (useKeyboard) {
            keyAdapter = new KeyListener();
            addKeyListener(keyAdapter);
            setFocusable(true);
            requestFocusInWindow();
        } else if (keyAdapter != null) {
            removeKeyListener(keyAdapter);
        }

        revalidate();
        repaint();

        // Shuffle the puzzle after 1 second
        Timer timer = new Timer(1000, e -> shufflePuzzle(SHUFFLE_MOVES));
        timer.setRepeats(false);
        timer.start();
    }

    private void shufflePuzzle(int moves) {
        Random rand = new Random();
        int[] directions = {-size, size, -1, 1}; // Up, Down, Left, Right

        for (int i = 0; i < moves; i++) {
            int move;
            while (true) {
                move = directions[rand.nextInt(4)];
                int newIndex = emptyIndex + move;

                if (isValidMove(newIndex, move)) {
                    buttons[emptyIndex].setText(buttons[newIndex].getText());
                    buttons[emptyIndex].setIcon(buttons[newIndex].getIcon());
                    buttons[newIndex].setText("");
                    buttons[newIndex].setIcon(null);
                    emptyIndex = newIndex;
                    break;
                }
            }
        }
    }

    private boolean isValidMove(int newIndex, int move) {
        if (newIndex < 0 || newIndex >= size * size) return false;
        if ((move == -1 || move == 1) && (newIndex / size != emptyIndex / size)) return false;
        return true;
    }

    private void exitToMainMenu() {
        if (keyAdapter != null) {
            removeKeyListener(keyAdapter);
        }
        remove(puzzlePanel);
        remove(controlPanel);
        showMainMenu();
        revalidate();
        repaint();
    }

    private List<BufferedImage> splitImage(BufferedImage image, int rows, int cols) {
        int pieceWidth = image.getWidth() / cols;
        int pieceHeight = image.getHeight() / rows;
        List<BufferedImage> images = new ArrayList<>(rows * cols);

        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                images.add(image.getSubimage(x * pieceWidth, y * pieceHeight, pieceWidth, pieceHeight));
            }
        }

        return images;
    }

    private class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (useKeyboard) return; // Prevent mouse actions if keyboard control is enabled

            JButton button = (JButton) e.getSource();
            int buttonIndex = -1;

            for (int i = 0; i < buttons.length; i++) {
                if (buttons[i] == button) {
                    buttonIndex = i;
                }
            }

            if (buttonIndex == -1) return;

            if (isAdjacent(emptyIndex, buttonIndex)) {
                buttons[emptyIndex].setText(button.getText());
                buttons[emptyIndex].setIcon(button.getIcon());
                button.setText("");
                button.setIcon(null);
                emptyIndex = buttonIndex;

                if (isSolved()) {
                    JOptionPane.showMessageDialog(puzzlePanel, "Congratulations! You solved the puzzle!");
                }
            }
        }

        private boolean isAdjacent(int emptyIndex, int buttonIndex) {
            int rowEmpty = emptyIndex / size;
            int colEmpty = emptyIndex % size;
            int rowButton = buttonIndex / size;
            int colButton = buttonIndex % size;

            return (Math.abs(rowEmpty - rowButton) == 1 && colEmpty == colButton) ||
                   (Math.abs(colEmpty - colButton) == 1 && rowEmpty == rowButton);
        }

        private boolean isSolved() {
            if (size * size != buttons.length) return false;

            for (int i = 0; i < buttons.length - 1; i++) {
                if (buttons[i].getText() == null || !buttons[i].getText().equals(String.valueOf(i + 1))) {
                    return false;
                }
            }

            return buttons[buttons.length - 1].getText() == null || buttons[buttons.length - 1].getText().equals("");
        }
    }

    private class KeyListener extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            int move = 0;

            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP:
                    move = size;
                    break;
                case KeyEvent.VK_DOWN:
                    move = -size;
                    break;
                case KeyEvent.VK_LEFT:
                    move = 1;
                    break;
                case KeyEvent.VK_RIGHT:
                    move = -1;
                    break;
            }

            int newIndex = emptyIndex + move;

            if (isValidMove(newIndex, move)) {
                buttons[emptyIndex].setText(buttons[newIndex].getText());
                buttons[emptyIndex].setIcon(buttons[newIndex].getIcon());
                buttons[newIndex].setText("");
                buttons[newIndex].setIcon(null);
                emptyIndex = newIndex;

                if (isSolved()) {
                    JOptionPane.showMessageDialog(puzzlePanel, "Congratulations! You solved the puzzle!");
                }
            }
        }

        private boolean isSolved() {
            if (size * size != buttons.length) return false;

            for (int i = 0; i < buttons.length - 1; i++) {
                if (buttons[i].getText() == null || !buttons[i].getText().equals(String.valueOf(i + 1))) {
                    return false;
                }
            }

            return buttons[buttons.length - 1].getText() == null || buttons[buttons.length - 1].getText().equals("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SlidingPuzzle puzzle = new SlidingPuzzle();
            puzzle.setVisible(true);
        });
    }
}